#!/bin/bash
set -e
cd /app

# Hash the source to check if recompilation is needed
SRC_HASH=$(md5sum src/index.ts src/ipc-mcp-stdio.ts 2>/dev/null | md5sum | cut -d" " -f1)
CACHE_HASH=""
[ -f /tmp/dist/.src-hash ] && CACHE_HASH=$(cat /tmp/dist/.src-hash)

if [ "$SRC_HASH" != "$CACHE_HASH" ] || [ ! -f /tmp/dist/index.js ]; then
  npx tsc --outDir /tmp/dist 2>&1 >&2
  ln -sf /app/node_modules /tmp/dist/node_modules
  echo "$SRC_HASH" > /tmp/dist/.src-hash
fi

cat > /tmp/input.json
node /tmp/dist/index.js < /tmp/input.json
