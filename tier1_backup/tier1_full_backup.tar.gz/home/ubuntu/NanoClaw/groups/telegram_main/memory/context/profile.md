# Philip Koh — User Profile

## Identity
- Founder/operator of Emtera LLC
- Security-conscious technologist
- Home IP: residential (changes periodically)

## Communication Preferences
- Prefers concise, direct responses
- Security-first mindset — never expose credentials
- Wants proactive updates on system status
- Uses Telegram as primary interface

## Technology Context
- Three-tier AI admin assistant (PhilClaw/PortalClaw/ReaderClaw)
- Personal email: philkoh.admin@gmail.com
- Amazon shopping via Gemini discovery + RapidAPI validation

## Active Projects
- NanoClaw Pro upgrade (semantic memory, proactive check-ins)
- Guided Browsing architecture (Section 19, planned)
- Portal onboarding (no real credentials yet)

## Daily Patterns
- Morning: email triage, task review
- Afternoon: project work, system checks
- Values: reliability, security, auditability
