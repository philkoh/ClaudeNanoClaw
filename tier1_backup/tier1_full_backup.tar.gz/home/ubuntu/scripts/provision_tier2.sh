#!/bin/bash
# provision_tier2.sh - Provisions a fresh Tier 2 VM from scratch
# Run this from Tier 1 against a fresh Ubuntu 24.04 Lightsail instance
# Usage: provision_tier2.sh <tier2_ip>
set -e

TIER2_IP="${1:-$(cat /home/ubuntu/tier2_ip.txt 2>/dev/null)}"
TIER1_IP="174.129.11.27"
VPC_DNS="172.26.0.2"
TIER2_KEY="/home/ubuntu/.ssh/tier2_key"

if [ -z "$TIER2_IP" ]; then
  echo "Usage: $0 <tier2_ip>"
  exit 1
fi

echo "=== Provisioning Tier 2 at $TIER2_IP ==="

# Wait for SSH to become available
echo "[1/7] Waiting for SSH..."
for i in $(seq 1 30); do
  ssh -i "$TIER2_KEY" -o StrictHostKeyChecking=accept-new -o ConnectTimeout=5 ubuntu@"$TIER2_IP" 'echo ok' >/dev/null 2>&1 && break
  echo "  Attempt $i..."
  sleep 10
done

SSH_CMD="ssh -i $TIER2_KEY -o StrictHostKeyChecking=accept-new ubuntu@$TIER2_IP"

# SSH hardening
echo "[2/7] Hardening SSH..."
$SSH_CMD "echo 'PasswordAuthentication no' | sudo tee /etc/ssh/sshd_config.d/no-password.conf > /dev/null && sudo systemctl reload ssh"

# Install packages
echo "[3/7] Installing packages..."
$SSH_CMD "sudo apt-get update -qq && sudo DEBIAN_FRONTEND=noninteractive apt-get install -y -qq docker.io squid dnsutils > /dev/null 2>&1 && sudo usermod -aG docker ubuntu"

# Disable unnecessary services
echo "[4/7] Disabling unnecessary services..."
$SSH_CMD "for svc in amazon-ssm-agent snap.amazon-ssm-agent.amazon-ssm-agent ModemManager snapd apache2 nginx lighttpd; do sudo systemctl disable --now \$svc 2>/dev/null || true; done"

# Configure Squid
echo "[5/7] Configuring Squid..."
$SSH_CMD bash << 'SQUIDSETUP'
sudo cp /etc/squid/squid.conf /etc/squid/squid.conf.orig 2>/dev/null || true
sudo touch /etc/squid/whitelist.txt
sudo chown proxy:proxy /etc/squid/whitelist.txt
sudo tee /etc/squid/squid.conf > /dev/null << 'SQUIDCONF'
http_port 127.0.0.1:3128
acl localnet src 127.0.0.1/32
acl SSL_ports port 443
acl CONNECT method CONNECT
acl allowed_domains dstdomain "/etc/squid/whitelist.txt"
acl anthropic_api dstdomain api.anthropic.com
http_access deny CONNECT !SSL_ports
http_access allow CONNECT anthropic_api
http_access allow CONNECT allowed_domains
http_access allow localnet anthropic_api
http_access allow localnet allowed_domains
http_access deny all
access_log daemon:/var/log/squid/access.log squid
cache_log /var/log/squid/cache.log
cache deny all
connect_timeout 30 seconds
read_timeout 60 seconds
via off
forwarded_for delete
SQUIDCONF
sudo systemctl restart squid
sudo systemctl enable squid
SQUIDSETUP

# Create scripts
echo "[6/7] Creating firewall scripts..."
$SSH_CMD "sudo mkdir -p /opt/scripts"

# Resolve Anthropic IPs
ANTHROPIC_IPS=$($SSH_CMD "dig +short api.anthropic.com | grep -E '^[0-9]' | sort -u")
$SSH_CMD "echo '$ANTHROPIC_IPS' | sudo tee /opt/scripts/anthropic_ips.txt > /dev/null"

# Transfer open_portal.sh
$SSH_CMD bash << 'OPENPORTAL'
sudo tee /opt/scripts/open_portal.sh > /dev/null << 'EOF'
#!/bin/bash
set -e
DOMAIN="$1"
if [ -z "$DOMAIN" ]; then echo "Usage: $0 <domain> [--cloudflare]"; exit 1; fi
echo "[open_portal] Opening egress for: $DOMAIN"
IPS=$(dig +short "$DOMAIN" | grep -E '^[0-9]')
if [ -z "$IPS" ]; then echo "[open_portal] WARNING: Could not resolve IPs for $DOMAIN"; exit 1; fi
for IP in $IPS; do
  sudo ufw allow out to "$IP" port 443 comment "portal:$DOMAIN"
  echo "[open_portal] Allowed outbound to $IP:443 ($DOMAIN)"
done
if ! grep -qxF "$DOMAIN" /etc/squid/whitelist.txt 2>/dev/null; then
  echo "$DOMAIN" | sudo tee -a /etc/squid/whitelist.txt > /dev/null
  echo "[open_portal] Added $DOMAIN to Squid whitelist"
fi
if [ "$2" == "--cloudflare" ]; then
  echo "[open_portal] Adding Cloudflare IP ranges..."
  CF_RANGES=$(curl -s https://www.cloudflare.com/ips-v4 2>/dev/null || echo "")
  if [ -z "$CF_RANGES" ]; then
    CF_RANGES="173.245.48.0/20 103.21.244.0/22 103.22.200.0/22 103.31.4.0/22 141.101.64.0/18 108.162.192.0/18 190.93.240.0/20 188.114.96.0/20 197.234.240.0/22 198.41.128.0/17 162.158.0.0/15 104.16.0.0/13 104.24.0.0/14 172.64.0.0/13 131.0.72.0/22"
  fi
  for CIDR in $CF_RANGES; do
    sudo ufw allow out to "$CIDR" port 443 comment "cloudflare:$DOMAIN"
  done
  echo "[open_portal] Cloudflare ranges added"
fi
sudo squid -k reconfigure 2>/dev/null || sudo systemctl reload squid 2>/dev/null || true
echo "[open_portal] Portal opened for $DOMAIN"
EOF
sudo chmod +x /opt/scripts/open_portal.sh
OPENPORTAL

# Transfer close_portal.sh
$SSH_CMD bash << CLOSEPORTAL
sudo tee /opt/scripts/close_portal.sh > /dev/null << 'EOF'
#!/bin/bash
set -e
TIER1_IP="$TIER1_IP"
VPC_DNS="$VPC_DNS"
echo "[close_portal] Resetting firewall to default deny..."
sudo ufw --force reset
sudo ufw default deny incoming
sudo ufw default deny outgoing
sudo ufw allow in from "\$TIER1_IP" to any port 22 comment "SSH from Tier 1"
sudo ufw allow out to 127.0.0.53 port 53 comment "DNS stub resolver"
sudo ufw allow out to "\$VPC_DNS" port 53 comment "VPC DNS server"
sudo ufw allow in on lo
sudo ufw allow out on lo
ANTHROPIC_IPS=\$(dig +short api.anthropic.com | grep -E '^[0-9]' | sort -u)
for IP in \$ANTHROPIC_IPS; do
  sudo ufw allow out to "\$IP" port 443 comment "Anthropic API"
done
sudo ufw --force enable
sudo truncate -s 0 /etc/squid/whitelist.txt
sudo squid -k reconfigure 2>/dev/null || sudo systemctl reload squid 2>/dev/null || true
echo "[close_portal] Firewall reset to baseline."
sudo ufw status numbered
EOF
sudo chmod +x /opt/scripts/close_portal.sh
CLOSEPORTAL

# Configure UFW
echo "[7/7] Configuring UFW..."
$SSH_CMD bash << UFWSETUP
sudo ufw --force reset
sudo ufw default deny incoming
sudo ufw default deny outgoing
sudo ufw allow in from $TIER1_IP to any port 22 comment "SSH from Tier 1"
sudo ufw allow out to 127.0.0.53 port 53 comment "DNS stub resolver"
sudo ufw allow out to $VPC_DNS port 53 comment "VPC DNS server"
sudo ufw allow in on lo
sudo ufw allow out on lo
for IP in $ANTHROPIC_IPS; do
  sudo ufw allow out to \$IP port 443 comment "Anthropic API"
done
sudo ufw --force enable
UFWSETUP

echo "=== Tier 2 Provisioning Complete ==="
$SSH_CMD "sudo ufw status verbose; echo '---'; sudo systemctl is-active docker squid; echo '---'; sudo ss -tlnp | grep -E '(3128|22)'"
