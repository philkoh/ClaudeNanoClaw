#!/bin/bash
# rebuild_tier2.sh - Destroys and recreates Tier 2 from scratch
# Run from Tier 1. Requires AWS CLI access and outbound HTTPS to Lightsail API.
set -e

INSTANCE_NAME="OpenClaw-Tier2"
STATIC_IP_NAME="OpenClaw-Tier2-IP"
BLUEPRINT="ubuntu_24_04"
BUNDLE="medium_3_0"
AZ="us-east-1a"
KEY_PAIR="NanoClaw-Tier1-Key"
TIER1_PUBKEY="ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIJe1ORLhNYQ7r8guXiCOH2cGEsVzc5N98hap+Utw7ZWN tier1-to-tier2"

echo "=== Rebuilding Tier 2 ($INSTANCE_NAME) ==="
echo "WARNING: This will DESTROY the current instance and all data on it."
echo "Press Ctrl+C within 5 seconds to abort..."
sleep 5

# 1. Detach static IP
echo "[1/7] Detaching static IP..."
aws lightsail detach-static-ip --static-ip-name "$STATIC_IP_NAME" 2>/dev/null || true

# 2. Destroy current instance
echo "[2/7] Deleting instance..."
aws lightsail delete-instance --instance-name "$INSTANCE_NAME"
sleep 30

# 3. Create user-data script to inject Tier 1 key
USERDATA=$(cat << 'UDEOF'
#!/bin/bash
echo "$TIER1_PUBKEY" >> /home/ubuntu/.ssh/authorized_keys
chown ubuntu:ubuntu /home/ubuntu/.ssh/authorized_keys
chmod 600 /home/ubuntu/.ssh/authorized_keys
UDEOF
)
# Replace the variable in userdata
USERDATA="#!/bin/bash
echo '$TIER1_PUBKEY' >> /home/ubuntu/.ssh/authorized_keys
chown ubuntu:ubuntu /home/ubuntu/.ssh/authorized_keys
chmod 600 /home/ubuntu/.ssh/authorized_keys"

# 4. Create fresh instance with user-data
echo "[3/7] Creating new instance with key injection..."
aws lightsail create-instances \
  --instance-names "$INSTANCE_NAME" \
  --blueprint-id "$BLUEPRINT" \
  --bundle-id "$BUNDLE" \
  --availability-zone "$AZ" \
  --key-pair-name "$KEY_PAIR" \
  --user-data "$USERDATA"

# 5. Wait for instance to be running
echo "[4/7] Waiting for instance to start..."
for i in $(seq 1 30); do
  STATE=$(aws lightsail get-instance --instance-name "$INSTANCE_NAME" \
    --query 'instance.state.name' --output text 2>/dev/null)
  echo "  State: $STATE"
  if [ "$STATE" = "running" ]; then break; fi
  sleep 10
done

# 6. Reattach static IP
echo "[5/7] Attaching static IP..."
aws lightsail attach-static-ip \
  --static-ip-name "$STATIC_IP_NAME" \
  --instance-name "$INSTANCE_NAME"

TIER2_IP=$(aws lightsail get-static-ip --static-ip-name "$STATIC_IP_NAME" \
  --query 'staticIp.ipAddress' --output text)
echo "Tier 2 IP: $TIER2_IP"
echo "$TIER2_IP" > /home/ubuntu/tier2_ip.txt

# Clear old host key
ssh-keygen -R "$TIER2_IP" 2>/dev/null || true

# 7. Wait for SSH then provision
echo "[6/7] Waiting for SSH (with key injection via user-data)..."
sleep 60  # Give cloud-init time to run user-data
for i in $(seq 1 30); do
  ssh -i /home/ubuntu/.ssh/tier2_key -o StrictHostKeyChecking=accept-new -o ConnectTimeout=5 \
    ubuntu@"$TIER2_IP" 'echo ok' >/dev/null 2>&1 && break
  echo "  Waiting for SSH (attempt $i)..."
  sleep 10
done

echo "[7/7] Running provisioning script..."
/home/ubuntu/scripts/provision_tier2.sh "$TIER2_IP"

echo "=== Tier 2 rebuild complete ==="
